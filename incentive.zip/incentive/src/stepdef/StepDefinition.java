package stepdef;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.util.List;
import java.util.Vector;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import Otherclasses.ConnectionManager;
import Otherclasses.ExcelToDb;
import Otherclasses.StepFailException;

public class StepDefinition {
	public String srcFileName;
	public String sourceCountQuery = "";
	public String sourceDataQuery = "";
	public String sourceIncQuery = "";
	public String trgIncSummaryQuery = "";

	@Given("^Connection with the database having INCENTIVE_SRC and INCENTIVE_TGT table$")
	public void javaToMysqlconnection() {
		//This method uses MYSQL plugin to connect to the local host MYSQL Database
		ConnectionManager.getConnection();
	}

	@Given("^Source data sheet INCENTIVE_SRC able at the location \"([^\"]*)\"$")
	public void sourceDataavailablity(String sourceFileName) throws FileNotFoundException {
		//Method to check whethere the soruce file is there and we can proceed with the ETL validation
		srcFileName = sourceFileName;
		File f = new File(sourceFileName);
		if (f.exists()) {
			System.out.println("Source file is existed at path :- " + sourceFileName);
		} else {
			System.out.println("Source file does not available at path :- " + sourceFileName);
			throw new FileNotFoundException();
		}

	}

	@When("^Data of the source data sheet is loaded to the INCENTIVE_SRC table\\.$")
	public void TemptableLoad() {
		//Loading the file data to MYSQL temp table to proceed with the validation
		System.out.println("-------Count validation INCENTIVE_TGT----------");
		ExcelToDb.saveToDatabase(ExcelToDb.read(srcFileName));
	}

	@When("^Count query for the source table is available at \"([^\"]*)\"$")
	public void Coutnqueryreader(String sourceCountQueryPath) throws IOException {
		//This method reads the count query to perform count validation
		BufferedReader sourceQueryBuffer = new BufferedReader(new FileReader(sourceCountQueryPath));
		String sourceLine;
		while ((sourceLine = sourceQueryBuffer.readLine()) != null) {
			sourceCountQuery = sourceCountQuery.concat(sourceLine + " ");
		}
		sourceQueryBuffer.close();
		System.out.println("Source query => " + sourceCountQuery);
	}

	@Then("^Compare the count of the source INCENTIVE_SRC and target INCENTIVE_TGT table$")
	public void Countvalidation() throws SQLException, StepFailException {
		//Performing count validation by comparing the source query count with the target table record count
		ResultSet rsSourceCount = ConnectionManager.con.createStatement().executeQuery(sourceCountQuery);
		rsSourceCount.next();
		int sourceCount = rsSourceCount.getInt(1);
		System.out.println("Number of records in source table : " + sourceCount);
		ResultSet rsTargetCount = ConnectionManager.con.createStatement()
				.executeQuery("select count(*) from INCENTIVE_TGT");
		rsTargetCount.next();
		int targetCount = rsTargetCount.getInt(1);
		System.out.println("Number of records in target table : " + targetCount);
		if (sourceCount == targetCount) {
			System.out.println("1.Count between the source query and target table is matching.");
		} else {
			//Failing the scenario when count is not matching
			System.out.println("1.Count between the source query and target table is not matching.");
			throw new StepFailException("Count between the source query and target table is not matching.");
		}
	}

	@Given("^Data query for the source table is available at \"([^\"]*)\"$")
	public void Dataqueryreader(String sourceDataQueryPath) throws Throwable {
		//Method to read the data query from the local path and load it to java env.

		System.out.println("-------Data validation INCENTIVE_TGT----------");

		BufferedReader sourceDataQueryBuffer = new BufferedReader(new FileReader(sourceDataQueryPath));
		String sourceLine;
		while ((sourceLine = sourceDataQueryBuffer.readLine()) != null) {
			sourceDataQuery = sourceDataQuery.concat(sourceLine + " ");
		}
		sourceDataQueryBuffer.close();
		System.out.println("Data query => " + sourceDataQuery);
	}

	@When("^the target and source tables are ready$")
	public void Dataloadcheck() throws Throwable {
		//Method to ensure the target table is loaded with the data through an ETL tool
		ResultSet rdAvail = ConnectionManager.con.createStatement().executeQuery("select count(*) from INCENTIVE_TGT");
		int Avail = 0;
		rdAvail.next();
		Avail = rdAvail.getInt(1);
		if (Avail != 0) {
			System.out.println("Data loaded to INCENTIVE_TGT table");
		} else {
			//Throw error when no data in target
			System.out.println("Data not loaded to the target table");
			throw new StepFailException("Data not loaded to the INCENTIVE_TGT table.Please verify");

		}

	}

	@Then("^validating the data between source and target table INCENTIVE_TGT$")
	public void Datavalidation_INCENTIVE_TGT() throws Throwable {
		// Validating the data between the source data query given and the target data
		ResultSet rsDatares = ConnectionManager.con.createStatement().executeQuery(sourceDataQuery);
		;
		if (!rsDatares.next()) {
			System.out.println("2.Data is matching with source and target");
		} else {
			System.out.println("2.Data validation failed");
			throw new StepFailException("Data is not matching between INCENTIVE_SRC and INCENTIVE_TGT");
		}

	}

	@Given("Connection with the database having INCENTIVE_TGT and INCENTIVE_SUMMARY tables")
	public void dbconnectionforsmry() {
		ConnectionManager.getConnection();
	}

	@When("^Source Query for the INCENTIVE_TGT is available at \"([^\"]*)\"\\.$")
	public void Sourcequerysmry(String srcIncQueryPath) throws IOException {
		//Method to read the source query to validate INCENTIVE_SUMMARY table
		System.out.println("---------------------Data validation INCENTIVE_SUMMARY------");
		BufferedReader sourceQueryBuffer = new BufferedReader(new FileReader(srcIncQueryPath));
		String sourceLine;
		while ((sourceLine = sourceQueryBuffer.readLine()) != null) {
			sourceIncQuery = sourceIncQuery.concat(sourceLine + " ");
			// Concatenating each line of query doc in the Source Incentive query String
		}
		sourceQueryBuffer.close();

	}

	@When("^Target Query for the INCENTIVE_SUMMARY is available at \"([^\"]*)\"\\.$")
	public void targetquerysmry(String trgIncSummaryQueryPath) throws IOException {
		BufferedReader sourceQueryBuffer = new BufferedReader(new FileReader(trgIncSummaryQueryPath));
		String sourceLine;
		while ((sourceLine = sourceQueryBuffer.readLine()) != null) {
			trgIncSummaryQuery = trgIncSummaryQuery.concat(sourceLine + " ");
			// Concatenating each line of query doc in the Source Incentive query String
		}
		sourceQueryBuffer.close();
	}

	@Then("^Compare the source incentive query data with target summary query data\\.$")
	public void Datavalidationsmry() throws Throwable {
		ResultSet rsS = ConnectionManager.con.createStatement().executeQuery(sourceIncQuery);
		ResultSet rsT = ConnectionManager.con.createStatement().executeQuery(trgIncSummaryQuery);
		int k = 0;
		rsS.next();
		rsT.next();
		//column wise data comparison
		if (rsS.getMetaData().getColumnCount() == rsT.getMetaData().getColumnCount()) {
			for (int i = 1; i <= rsT.getMetaData().getColumnCount(); i++) {
				if (i != 5) {
					if (rsS.getInt(i) != rsT.getInt(i)) {
						k++;
						System.out.println("Value between source and target query for column "
								+ rsT.getMetaData().getColumnName(i) + " is not matching.");
					} else {
						System.out.println("Value between source and target query for column "
								+ rsT.getMetaData().getColumnName(i) + " is matching.");
					}
				} else {
					if (rsS.getDouble(i) != rsT.getDouble(i)) {
						k++;
						System.out.println("Value between source and target query for column "
								+ rsT.getMetaData().getColumnName(i) + " is not matching.");
					} else {
						System.out.println("Value between source and target query for column "
								+ rsT.getMetaData().getColumnName(i) + " is matching.");
					}
				}
				if (k > 0) {
					System.out.println("Source query data and target table data is not matching");
					throw new StepFailException("Source query data and target table data is not matching");
				}
			}
			System.out.println("3.Data validation between INCENTIVE_TGT and INCENTIVE_SUMMARY is passed");

		} else {
			System.out.println("No of columns in source and target query are not matching. Please check query.");
			throw new StepFailException(
					"No of columns in source and target query are not matching. Please check query.");
		}

	}

	@Given("^Data load is completed for the INCENTIVE_TGT table i\\.e number of records >(\\d+)$")
	public void Dataloadcheck(int arg1) throws Throwable {
		System.out.println("---------------------Duplicate validation  INCENTIVE_TGT-----------------------");
		ResultSet rAvail = ConnectionManager.con.createStatement().executeQuery("select count(*) from INCENTIVE_TGT");
		int Avail = 0;
		rAvail.next();
		Avail = rAvail.getInt(1);
		if (Avail != 0) {
			System.out.println("Data loaded to INCENTIVE_TGT table");
		} else {
			System.out.println("Data not loaded to the target table");
			throw new StepFailException("Data not loaded to the INCENTIVE_TGT table.Please verify");

		}

	}

	@Then("^Validating the table for duplicate records$")
	public void Duplicatevalidation() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ResultSet rsnondistCnt = ConnectionManager.con.createStatement().executeQuery(
				"select count(*) from (select SubscriberId, EffectiveDate, EndDate, TotalIncentiveAmt, StepStatus, OverallStatus, NoofCycles from INCENTIVE_TGT) a");
		rsnondistCnt.next();
		int nondistCnt = rsnondistCnt.getInt(1);
		ResultSet rsdistCnt = ConnectionManager.con.createStatement().executeQuery(
				"select count(*) from (select distinct SubscriberId, EffectiveDate, EndDate, TotalIncentiveAmt, StepStatus, OverallStatus, NoofCycles from INCENTIVE_TGT) a");
		rsdistCnt.next();
		int distCnt = rsdistCnt.getInt(1);
		if (nondistCnt == distCnt) {
			System.out.println("4.No duplicates in INCENTIVE_TGT : Duplicate validation passed");
		} else {
			System.out.println("4.INCENTIVE_TGT table has duplicate values");
			System.out.println(nondistCnt);
			System.out.println(distCnt);
			throw new StepFailException("4.Duplicate validation failed for INCENTIVE_TGT");
		}
	}
	
	@Then("^Validating metadata for INCENTIVE_SRC and INCENTIVE_TGT$")
	public void metaDatavalidation() throws SQLException, StepFailException {
		// Comparing source file column with the INCENTIVE_SRC table column
		System.out.println("-----------Metadata validation---------");
		Vector<Object> dataHolder = ExcelToDb.read("C:\\Users\\Administrator\\eclipse-workspace\\incentive\\Sourcedata\\INCENTIVE_SRC.xlsx");
		@SuppressWarnings("unchecked")
		List<Object> sourceHeader = (List<Object>) dataHolder.get(0); // Header column in a list
		ResultSet rsSrc = ConnectionManager.con.createStatement().executeQuery("select * from INCENTIVE_SRC");
		ResultSetMetaData rsMD = rsSrc.getMetaData();
		int q = 0;
		if (sourceHeader.size() == rsMD.getColumnCount()) {
			for (int i = 0; i < sourceHeader.size(); i++) {
				if (!rsMD.getColumnName(i + 1).equals(sourceHeader.get(i).toString())) {
					q++;
					System.out.println("Source column having name '" + sourceHeader.get(i)
							+ "' is not matching with table column name i.e. '" + rsMD.getColumnName(i + 1) + "'.");
				}
			}
		} else {
			q++;
			System.out.println("Number of the columns in the source file and INCENTIVE_SRC table are not matching.");
		}
		//Now checking data type and column name for INCENTIVE_TGT table
		int v=0;
		ResultSet rsTgt = ConnectionManager.con.createStatement().executeQuery("select * from INCENTIVE_TGT");
		ResultSetMetaData rsMDTgt = rsTgt.getMetaData();
		//Checking name, data type for first column
		if(!rsMDTgt.getColumnName(1).equals("SubscriberId") || !rsMDTgt.getColumnTypeName(1).equals("INT")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(1)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(2).equals("EffectiveDate") || !rsMDTgt.getColumnTypeName(2).equals("DATE")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(2)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(3).equals("EndDate") || !rsMDTgt.getColumnTypeName(3).equals("DATE")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(3)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(4).equals("TotalIncentiveAmt") || !rsMDTgt.getColumnTypeName(4).equals("DECIMAL")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(4)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(5).equals("StepStatus") || !rsMDTgt.getColumnTypeName(5).equals("VARCHAR")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(5)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(6).equals("OverallStatus") || !rsMDTgt.getColumnTypeName(6).equals("CHAR")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(6)+" is not correct.");
		}
		if(!rsMDTgt.getColumnName(7).equals("NoofCycles") || !rsMDTgt.getColumnTypeName(7).equals("INT")) {
			v++;
			System.out.println("Meta data for column "+rsMDTgt.getColumnName(7)+" is not correct.");
		}
		if (q == 0) {
			System.out.println("5.1 Source file columns' name matches with INCENTIVE_SRC table columns' name.");
		} 
		if (v == 0) {
			System.out.println("5.2 Metadata for table INCENTIVE_TGT is correct.");
		} 
		if(q>0){
			System.out.println("5.1 Source file columns' name do not matches with INCENTIVE_SRC table columns' name.");
			System.out.println("Scenario fifth fails.");
			throw new StepFailException(
					"5.1 Source file's columns' name do not matches with INCENTIVE_SRC table's columns' name.");
		}
		if(v>0) {
			System.out.println("5.2 Meta data for table INCENTIVE_TGT is not correct.");
			System.out.println("Scenario fifth fails.");
			throw new StepFailException(
					"Meta data for table INCENTIVE_TGT is not correct.");
		}
	}

}
