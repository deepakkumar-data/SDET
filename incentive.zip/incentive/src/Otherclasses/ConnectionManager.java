package Otherclasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	public static Connection con = null;

	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CAPSTONE", "root", "admin");
			System.out.println("Connected to database");
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return con;
	}
}
