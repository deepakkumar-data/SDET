package Otherclasses;

public class StepFailException extends Exception {
	private static final long serialVersionUID = 1L;

	public StepFailException(String message) {
		super(message);
	}
}
