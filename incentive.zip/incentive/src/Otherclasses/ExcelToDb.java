package Otherclasses;

import java.io.FileInputStream;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelToDb {
	static Connection con = ConnectionManager.con;
	Vector<Object> dataHolder = null;
	private static XSSFWorkbook myWorkBook;

	public static Vector<Object> read(String fileName) {
		Vector<Object> cellVectorHolder = new Vector<Object>();
		try {
			// Data load to vector object
			FileInputStream myInput = new FileInputStream(fileName);
			myWorkBook = new XSSFWorkbook(myInput);
			XSSFSheet mySheet = myWorkBook.getSheetAt(0);
			Iterator<Row> rowIter = mySheet.rowIterator();
			while (rowIter.hasNext()) {
				XSSFRow myRow = (XSSFRow) rowIter.next();
				Iterator<Cell> cellIter = myRow.cellIterator();
				List<Object> list = new ArrayList<Object>();
				while (cellIter.hasNext()) {
					XSSFCell myCell = (XSSFCell) cellIter.next();
					list.add(myCell);
				}
				cellVectorHolder.addElement(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cellVectorHolder;
	}

	public static void saveToDatabase(Vector<Object> dataHolder) {
		boolean flag = true;
		int SubscriberId = 0;
		String IncentiveStep = "";
		java.sql.Date IncentiveEffDate = null;
		java.sql.Date IncentiveEndDate = null;
		double IncentiveAmount = 0;

		con = ConnectionManager.getConnection();

		try {
			con.createStatement().execute("truncate INCENTIVE_SRC");
		} catch (SQLException e1) {
			e1.printStackTrace();
			flag = false;
		}
		int i = 0;
		for (Iterator<Object> iterator = dataHolder.iterator(); iterator.hasNext();) {
			@SuppressWarnings("unchecked")
			List<Object> list = (List<Object>) iterator.next();
			i++;
			if (i != 1) {
				SubscriberId = Integer.parseInt(list.get(0).toString().replace(".0", ""));
				IncentiveStep = list.get(1).toString();
				SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
				try {
					IncentiveEffDate = new java.sql.Date(format.parse(list.get(2).toString()).getTime());
					IncentiveEndDate = new java.sql.Date(format.parse(list.get(3).toString()).getTime());
				} catch (ParseException e1) {
					e1.printStackTrace();
					flag = false;
				}
				if (!list.get(4).toString().isEmpty()) {
					IncentiveAmount = Double.parseDouble(list.get(4).toString());
				} else {
					IncentiveAmount = 0;
				}
				try {
					PreparedStatement stmt = con.prepareStatement(

							// Loading data to the database
							"INSERT INTO INCENTIVE_SRC(SubscriberId,IncentiveStep,IncentiveEffDate,IncentiveEndDate,IncentiveAmount) VALUES(?,?,?,?,?)");
					stmt.setInt(1, SubscriberId);
					stmt.setString(2, IncentiveStep);
					stmt.setDate(3, IncentiveEffDate);
					stmt.setDate(4, IncentiveEndDate);
					stmt.setDouble(5, IncentiveAmount);
					stmt.executeUpdate();
				} catch (SQLException e) {
					e.printStackTrace();
					flag = false;
				}
			}
		}
		if (flag) {
			System.out.println("Source file date is loaded in database");
		} else {
			System.out.println("There is error whileloading data in database");

		}
	}

}
